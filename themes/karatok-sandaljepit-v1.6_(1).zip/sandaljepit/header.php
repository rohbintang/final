<!doctype html>

<!--[if lt IE 7]><html <?php language_attributes(); ?> class="no-js lt-ie9 lt-ie8 lt-ie7"><![endif]-->
<!--[if (IE 7)&!(IEMobile)]><html <?php language_attributes(); ?> class="no-js lt-ie9 lt-ie8"><![endif]-->
<!--[if (IE 8)&!(IEMobile)]><html <?php language_attributes(); ?> class="no-js lt-ie9"><![endif]-->
<!--[if gt IE 8]><!--> <html <?php language_attributes(); ?> class="no-js"><!--<![endif]-->

	<head>
		<meta charset="utf-8">

		<?php global $karatok; ?>

		<title><?php wp_title( '|', true, 'right' ); ?></title>

		<?php // mobile meta (hooray!) ?>
		<meta name="HandheldFriendly" content="True">
		<meta name="MobileOptimized" content="320">
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>

		<link rel="apple-touch-icon" href="<?php echo $karatok['favicon']['url']; ?>">
		<link rel="icon" href="<?php echo $karatok['favicon']['url']; ?>">
		<!--[if IE]>
		<link rel="shortcut icon" href="<?php echo $karatok['favicon']['url']; ?>">
		<![endif]-->
		<?php // or, set /favicon.ico for IE10 win ?>
		<meta name="msapplication-TileImage" content="<?php echo $karatok['favicon']['url']; ?>">
		<meta name="msapplication-TileColor" content="<?php echo $karatok['opt-link-color']['hover']; ?>">

		<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>">
		<link href="//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">

		<?php wp_head(); ?>

	</head>

	<body <?php body_class(); ?>>

		<div id="container" class="sb-site-container">
			<header id="top" class="header" role="banner">
				<section id="header-box" class="wrap clearfix">
					<div class="header-kiri threecol first">
						<?php if( $karatok['pinbb'] ) : ?><div class="sj-bbm"><?php echo $karatok['pinbb']; ?></div><?php endif; ?>
						<?php if( $karatok['nohp'] ) : ?><div class="sj-telp"><?php echo $karatok['nohp']; ?></div><?php endif; ?>
						<?php if( $karatok['nowa'] ) : ?><div class="sj-whatsapp"><?php echo $karatok['nowa']; ?></div><?php endif; ?>
						<?php if( $karatok['email'] ) : ?><div class="sj-email"><?php echo $karatok['email']; ?></div><?php endif; ?>
					</div>
					<div class="header-tengah logo sixcol">
						<?php if ( ! is_singular() ) { echo '<h1>'; } ?><a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php esc_attr_e( get_bloginfo( 'name' ), 'sandaljepit' ); ?>" rel="home"><?php if( $karatok['logo']['url'] ) : ?><img src="<?php echo $karatok['logo']['url']; ?>" alt="<?php echo esc_html( get_bloginfo( 'name' ) ); ?>"><?php else : ?><?php echo esc_html( get_bloginfo( 'name' ) ); ?><?php endif; ?></a><?php if ( ! is_singular() ) { echo '</h1>'; } ?>
						<?php if( $karatok['deskripsion'] ) : ?><p class="site-description"><?php bloginfo( 'description' ); ?></p><?php endif; ?>
						<div id="search"><?php get_search_form(); ?></div>
					</div>
					<div class="header-kanan threecol last">
						<div class="sj-cart clearfix">
							<div class="h2 cart-num">Rp 0</div>
							<div class="sj-checkout-box twelvecol first clearfix">
								<div class="cart-item sixcol first">0 item</div>
								<?php $cp = $karatok['checkoutpage']; ?><?php if( $cp ) : ?><a class="sj-checkout sixcol last" href="<?php echo get_permalink($cp); ?>"><?php echo get_the_title($cp); ?><i class="fa fa-shopping-cart"></i></a><?php endif; ?>
								<?php if( !is_page($cp) ) : ?><div id="jcart" style="display:none"><?php karatok_display_jcart(); ?></div><?php endif; ?>
							</div>
						</div>
						<div class="sb-toggle-left">
							<div class="navicon-box">
								<div class="navicon-line"></div>
								<div class="navicon-line"></div>
								<div class="navicon-line"></div>
							</div>
							<div class="navicon-text">menu</div>
						</div>

					</div>
				</section>
				<nav class="wrap clearfix" role="navigation">
					<?php karatok_main_nav(); ?>
				</nav>
			</header>
