<?php
// Include jcart before session start
include_once(TEMPLATEPATH . '/functions/jcart/jcart.php');

global $karatok;
$config = $jcart->config;

// The update and empty buttons are displayed when javascript is disabled
// Re-display the cart if the visitor has clicked either button
if ($_POST['jcartUpdateCart'] || $_POST['jcartEmpty']) {

	// Update the cart
	if ($_POST['jcartUpdateCart']) {
		if ($jcart->update_cart() !== true)	{
			$_SESSION['quantityError'] = true;
		}
	}

	// Empty the cart
	if ($_POST['jcartEmpty']) {
		$jcart->empty_cart();
	}

	// Redirect back to the checkout page
	$protocol = 'http://';
	if (!empty($_SERVER['HTTPS'])) {
		$protocol = 'https://';
	}
	$cp = $karatok['checkoutpage'];
	header('Location: ' . get_permalink($cp));
	exit;
}

else if (isset($_POST['sjtombolbeli'])) {
	if( !isset( $_POST['nama'] ) || !is_email( $_POST['email'] ) || !isset( $_POST['alamat'] ) || !isset( $_POST['kodepos'] ) ||
		!isset( $_POST['telpon'] ) || !isset( $_POST['kecamatan'] ) || !isset( $_POST['kabupaten'] ) ||
		!isset( $_POST['provinsi'] ) || !isset( $_POST['tarifjne'] ) ) {
		$pesan['status'] = 'error';
		$pesan['pesan'] = "Semua data harus diisi dengan benar.";
	} else {
		$validPrices = true;
		if ($validPrices !== true)	{
			$pesan['status'] = 'error';
			$pesan['pesan'] = $config['text']['checkoutError'];
		} elseif ($validPrices === true) {
			$namatoko = $karatok['namatoko'];
			$alamattoko = str_replace("\n", '<br>', trim($karatok['alamattoko']));
			$alamatemail = $karatok['emailtoko'];

			$nama = $_POST['nama'];
			$email = $_POST['email'];
			$alamat = $_POST['alamat'];
			$kodepos = $_POST['kodepos'];
			$telpon = $_POST['telpon'];
			$catatan = $_POST['catatan'];
			$kecamatan = explode("|", $_POST['kecamatan']);
			$kecamatan = $kecamatan[0];
			$kabupaten = $_POST['kabupaten'];
			$provinsi =  ucwords( strtolower( $_POST['provinsi'] ) );
			$tarifjne = karatok_price( $_POST['tarifjne'], 0 );
			$sjweight = $_POST['sjweight'];
			$totalongkir = karatok_price( $_POST['totalongkir2'], 0 );
			$subtotal = karatok_price( $_POST['sjsubtotal'], 0 );
			$totalorder = karatok_price( $_POST['sjtotalan'], 0 );
			$layanan = strtoupper( str_replace( 'jne', 'jne ', $_POST['sjlayananjne'] ) );
			$noinvoice = date("YmdHis");
			$tanggal = date("d/m/Y H:i:s");

			$subject = $namatoko . " Order Detail #$noinvoice";

			$headers = "From: $namatoko <$alamatemail> \r\n";
			$headers .= "Reply-To: $namatoko <$alamatemail> \r\n";
			$headers .= "CC: $alamatemail\r\n";
			$headers .= "MIME-Version: 1.0\r\n";
			$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

			$message = "<html><body style=\"font-family:'Verdana',Arial,Helvetica,sans-serif;font-size:12px;color:#333;\">";
			$message .= "<table cellspacing='0' cellpadding='0' border='0' width='100%' style=\"font-family:'Verdana',Arial,Helvetica,sans-serif;font-size:12px;color:#333;\">
							<tbody>";

			if( $karatok['logo']['url'] ) $message .= "<tr><td colspan='2' style='padding:5px;text-align:center;border-bottom:1px solid #ccc;'><a href='". get_bloginfo( 'url' ) ."'><img src='{$karatok['logo']['url']}' alt='".esc_html( get_bloginfo( 'name' ) )."'></a></td></tr>";

			$message .=	"<tr>
									<td style='vertical-align:top;padding:5px;'>
										Nomor Order: #$noinvoice<br>
										Tanggal Order: $tanggal
									</td>
									<td align='right' style='vertical-align:top;padding:5px;'>
										<b>$totalorder</b>
									</td>
								</tr>
								<tr><td style='padding:5px;' colspan='2'></td></tr>
								<tr>
									<td style='vertical-align:top;padding:5px;'>
										<b>$namatoko</b><br>
										$alamattoko<br>
										$alamatemail
									</td>
									<td align='right' style='vertical-align:top;padding:5px;'>
										<b>$nama</b><br>
										$alamat<br>
										$kecamatan, $kabupaten, $provinsi<br>
										$kodepos<br>
										$telpon<br>
										$email
									</td>
								</tr>
								<tr>
									<td style='padding:10px;' colspan='2'></td>
								</tr>
							</tbody>
						</table>

						<table cellspacing='0' cellpadding='0' border='0' width='100%' style=\"font-family:'Verdana',Arial,Helvetica,sans-serif;font-size:12px;color:#333;margin-top:20px\">
							<thead>
								<tr>
									<th style='border-bottom:1px solid #ccc;padding:5px;' width='45%' align='left'>PRODUK</th>
									<th style='border-bottom:1px solid #ccc;padding:5px;' width='10%' align='right'>BERAT</th>
									<th style='border-bottom:1px solid #ccc;padding:5px;' width='20%' align='right'>HARGA</th>
									<th style='border-bottom:1px solid #ccc;padding:5px;' width='5%'  align='right'>JUMLAH</th>
									<th style='border-bottom:1px solid #ccc;padding:5px;' width='20%' align='right'>SUBTOTAL</th>
								</tr>
							</thead>
							<tbody>";
								foreach ($jcart->get_contents() as $item) {
									$itemprice	= karatok_price( $item['price'], 0 );
									$itemweight	= number_format( $item['weight'], 1, '.', ',' );
									$subtot	= karatok_price( ( $item['price'] * $item['qty'] ), 0 );
									$message .= "<tr>";
									$message .= "<td style='border-bottom:1px solid #ccc;padding:5px;'><a href='{$item['url']}'>{$item['name']}</a></td>";
									$message .= "<td style='border-bottom:1px solid #ccc;padding:5px;' align='right'>$itemweight Kg</td>";
									$message .= "<td style='border-bottom:1px solid #ccc;padding:5px;' align='right'>$itemprice</td>";
									$message .= "<td style='border-bottom:1px solid #ccc;padding:5px;' align='right'>{$item['qty']}</td>";
									$message .= "<td style='border-bottom:1px solid #ccc;padding:5px;' align='right'>$subtot</td>";
									$message .= "</tr>";
								}
								$message .= "<tr>
									<td style='padding:5px;' colspan='5'></td>
								</tr>
								<tr>
									<td style='border-bottom:1px solid #ccc;padding:5px;' align='right' colspan='4'>Subtotal</td>
									<td style='border-bottom:1px solid #ccc;padding:5px;' align='right'>$subtotal</td>
								</tr>
								<tr>
									<td style='padding:5px;' colspan='5'></td>
								</tr>
								<tr>
									<td style='border-bottom:1px solid #ccc;padding:5px;' align='right' colspan='4'>Ekspedisi $layanan ($sjweight Kg)</td>
									<td style='border-bottom:1px solid #ccc;padding:5px;' align='right'>$totalongkir</td>
								</tr>
								<tr>
									<td style='padding:5px;' colspan='5'></td>
								</tr>
								<tr>
									<td style='border-bottom:1px solid #ccc;padding:5px;' align='right' colspan='4'><b>TOTAL</b></td>
									<td style='border-bottom:1px solid #ccc;padding:5px;' align='right'><b>$totalorder</b></td>
								</tr>
							</tbody>
						</table>";

			if( trim( $catatan ) ) {
				$message .= "<div style='background:#ccc;margin:15px 0;padding:10px;'>";
				$message .= "<p style='line-height:1.5em;margin:0;'><b>Catatan</b>: " . str_replace( array("\r\n", "\r", "\n"), "<br>", $catatan ) . "</p>";
				$message .= "</div>";
			}

			$message .= "<div style='margin:15px 0;'>";
			$message .= "<h4>Daftar Nomor Rekening kami:</h4><ul style='padding:0;'>";
			foreach( $karatok['rekbank'] as $bank ) :
				$bank = explode( '|', $bank );
				$bank[0] = strtoupper( $bank[0] );
				$message .= "<li style='border:1px solid #ddd;margin:0 5px 5px 0;padding:0 5px 0 0;display:inline-block'><span style='font-weight:bold;background:#ccc;padding:14px 5px;float:left;margin-right:5px'>{$bank[0]}</span><span style='float:left;padding:5px 0;'>{$bank[1]}<br>{$bank[2]}</span></li>";
			endforeach;
			$message .= "</ul></div>";

			$message .= "<div style='margin:15px 0;'>";
			$message .= "<h4>Daftar Customer Service kami:</h4><ul style='padding:0;'>";
			foreach( $karatok['kontak'] as $kontak ) :
				$kontak = explode( '|', $kontak );
				$kontak[0] = strtoupper( $kontak[0] );
				$message .= "<li style='border:1px solid #ddd;margin:0 5px 5px 0;padding:5px 5px 5px 0;display:inline-block'><span style='font-weight:bold;background:#ccc;padding:5px;margin-right:5px'>{$kontak[0]}</span>{$kontak[1]}</li>";
			endforeach;
			$message .= "</ul></div>";
			$message .= "<div style='margin:15px 0;'>{$karatok['emailnote']}</div>";

			$message .= "<div style='margin:15px 0;'>Terima kasih<br><a href='". get_bloginfo( 'url' ) ."'>{$karatok['namatoko']}</a></div>";
			$message .= "</body></html>";

			if( mail( $email, $subject, $message, $headers ) ) {
				$jcart->empty_cart();
				$pesan['status'] = 'success';
				$pesan['pesan'] = "Terima kasih, $nama. Silakan cek email Anda untuk detail pemesanan Anda.";
			} else {
				$pesan['status'] = 'error';
				$pesan['pesan'] = "Proses checkout gagal. Silakan ulangi beberapa saat lagi.";
			}
		}
	}
}

/*
* Template Name: Checkout
*/
get_header(); ?>

			<div id="content">

				<div id="inner-content" class="wrap clearfix">

						<div id="main" class="ninecol last clearfix" role="main">

							<div id="breadcrumbs" class="breadcrumbs clearfix"><?php karatok_breadcrumbs() ?></div>

							<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

							<article id="post-<?php the_ID(); ?>" <?php post_class( 'clearfix' ); ?> role="article" itemscope itemtype="http://schema.org/BlogPosting">

								<header class="article-header">

									<h1 class="page-title" itemprop="headline"><?php the_title(); ?></h1>
									<?php if( isset( $pesan['status'] ) ) : ?><div class="alert alert-<?php echo $pesan['status']; ?>"><p><?php echo $pesan['pesan']; ?></p></div><?php endif; ?>

								</header>

								<section class="entry-content clearfix" itemprop="articleBody">
									<?php //the_content(); ?>
<form method="post" action="<?php the_permalink(); ?>" id="checkoutform">
<div id="jcart"><?php $jcart->display_cart(); ?></div>
<div class="checkout-box">
	<h4>ISI DATA DENGAN LENGKAP</h4>
	<div class="nama">
		<label for="nama">Nama</label><input type="text" name="nama" id="nama" required>
	</div>
	<div class="email">
		<label for="email">Email</label><input type="text" name="email" id="email" required>
	</div>
	<div class="alamat">
		<label for="alamat">Alamat</label><input type="text" name="alamat" id="alamat" required>
	</div>
	<div class="kodepos">
		<label for="kodepos">Kodepos</label><input type="text" name="kodepos" id="kodepos" required>
	</div>
	<div class="telpon">
		<label for="telpon">Telpon</label><input type="text" name="telpon" id="telpon" required>
	</div>
	<div class="catatan">
		<label for="catatan">Catatan</label><textarea name="catatan" id="catatan"></textarea>
	</div>
	<div class="provinsi">
		<label for="provinsi">Provinsi</label>
		<select id="provinsi" name="provinsi" required>
			<option value="">PILIH PROVINSI:</option>
			<option value="ACEH">ACEH</option>
			<option value="BALI">BALI</option>
			<option value="BANGKA BELITUNG">BANGKA BELITUNG</option>
			<option value="BANTEN">BANTEN</option>
			<option value="BENGKULU">BENGKULU</option>
			<option value="DI YOGYAKARTA">DI YOGYAKARTA</option>
			<option value="DKI JAKARTA">DKI JAKARTA</option>
			<option value="GORONTALO">GORONTALO</option>
			<option value="JAMBI">JAMBI</option>
			<option value="JAWA BARAT">JAWA BARAT</option>
			<option value="JAWA TENGAH">JAWA TENGAH</option>
			<option value="JAWA TIMUR">JAWA TIMUR</option>
			<option value="KALIMANTAN BARAT">KALIMANTAN BARAT</option>
			<option value="KALIMANTAN SELATAN">KALIMANTAN SELATAN</option>
			<option value="KALIMANTAN TENGAH">KALIMANTAN TENGAH</option>
			<option value="KALIMANTAN TIMUR">KALIMANTAN TIMUR</option>
			<option value="KEPULAUAN RIAU">KEPULAUAN RIAU</option>
			<option value="LAMPUNG">LAMPUNG</option>
			<option value="MALUKU">MALUKU</option>
			<option value="MALUKU UTARA">MALUKU UTARA</option>
			<option value="NUSA TENGGARA BARAT">NUSA TENGGARA BARAT</option>
			<option value="NUSA TENGGARA TIMUR">NUSA TENGGARA TIMUR</option>
			<option value="PAPUA">PAPUA</option>
			<option value="PAPUA BARAT">PAPUA BARAT</option>
			<option value="RIAU">RIAU</option>
			<option value="SULAWESI BARAT">SULAWESI BARAT</option>
			<option value="SULAWESI SELATAN">SULAWESI SELATAN</option>
			<option value="SULAWESI TENGAH">SULAWESI TENGAH</option>
			<option value="SULAWESI TENGGARA">SULAWESI TENGGARA</option>
			<option value="SULAWESI UTARA">SULAWESI UTARA</option>
			<option value="SUMATERA BARAT">SUMATERA BARAT</option>
			<option value="SUMATERA SELATAN">SUMATERA SELATAN</option>
			<option value="SUMATERA UTARA">SUMATERA UTARA</option>
		</select>
	</div>
	<div class="kabupaten" style="display:none">
		<label for="kabupaten">Kabupaten</label>
		<select id="kabupaten" name="kabupaten" required></select>
	</div>
	<div class="kecamatan" style="display:none">
		<label for="kecamatan">Kecamatan</label>
		<select id="kecamatan" name="kecamatan" required></select>
	</div>
	<div class="ongkir" style="display:none">
		<h4>PILIH EKSPEDISI PENGIRIMAN</h4>
		<div class="JNE">JNE</div>
		<div id="ongkir"></div>
	</div>
	<div class="totalongkir" style="display:none">
		Ongkos Kirim <span id="totalkg">0</span> Kg: <span id="totalongkir"></span>
		<input type="hidden" id="totalongkir2" name="totalongkir2" value="0">
	</div>
	<div class="sjtotal" style="display:none">
		Total: <span id="sjtotal"></span>
		<input type="hidden" id="sjtotalan" name="sjtotalan" value="0">
	</div>
	<div class="sjtombolbeli">
		<input type="submit" name="sjtombolbeli" class="alignright button" value="Submit Order">
	</div>
</div>
</form>
								</section>

								<footer class="article-footer">

								</footer>

								<?php //comments_template(); ?>

							</article>

							<?php endwhile; else : ?>

									<article id="post-not-found" class="hentry clearfix">
										<header class="article-header">
											<h1><?php _e( 'Oops, Post Not Found!', 'karatok' ); ?></h1>
										</header>
										<section class="entry-content">
											<p><?php _e( 'Uh Oh. Something is missing. Try double checking things.', 'karatok' ); ?></p>
										</section>
										<footer class="article-footer">
												<p><?php _e( 'This is the error message in the page.php template.', 'karatok' ); ?></p>
										</footer>
									</article>

							<?php endif; ?>

						</div>

						<?php get_sidebar(); ?>

				</div>

			</div>

<?php get_footer(); ?>