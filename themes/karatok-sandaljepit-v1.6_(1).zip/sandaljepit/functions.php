<?php
/*
Author: Karatok
URL: htp://karatok.com/
*/

include (TEMPLATEPATH . '/library/sandaljepit.php' );

/*========= ADD YOUR CODE BELOW =========*/

?>