<?php
add_action( 'widgets_init', 'post_category_widget_init' );
function post_category_widget_init() {
	register_widget( 'post_category_widget' );
}
class post_category_widget extends WP_Widget {
	function post_category_widget() {
		$widget_ops = array( 'classname' => 'post-category-widget', 'description' => 'Tampilkan Produk menurut kategori produk'  );
		$this->WP_Widget( 'post-category-widget', 'Karatok Produk Per Kategori', $widget_ops );
	}

	function widget( $args, $instance ) {
		global $post;
		extract($args);

		// Widget options
		$title 	 = apply_filters('widget_title', $instance['title'] );
		$number	 = $instance['number'];
		$category= $instance['category'];

        // Output
		echo $before_widget;

	    if ( $title ) echo $before_title . $title . $after_title;

		$mlq = new WP_Query(array( 'post_type' => 'post', 'posts_per_page' => $number, 'cat' => $category ));
		if( $mlq->have_posts() ) : while($mlq->have_posts()) : $mlq->the_post(); ?>
		   <article <?php post_class( 'produk-widget clearfix' ); ?> role="article">
				<?php extract(karatok_post_meta()); ?>
				<header class="article-header">
					<div class="box-entry">
						<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
							<div class="entry-thumb-widget">
								<?php the_post_thumbnail('thumbnail'); ?>
							</div>
							<h3 class="entry-title-widget"><?php the_title(); ?></h3>
						</a>
						<span class="harga-produk-widget"><?php karatok_price( $hargadiskon ); ?></span>
						<?php if( $diskon ) : ?><span class="diskon-per-widget">-<?php echo $diskon."%"; ?></span><?php endif; ?>
					</div>
				</header>
			</article>
		<?php endwhile; endif; wp_reset_query();
		echo $after_widget;
	}

	/** Widget control update */
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title']  = strip_tags( $new_instance['title'] );
		$instance['number'] = strip_tags( $new_instance['number'] );
		$instance['category'] = strip_tags( $new_instance['category'] );
		return $instance;
	}

	/**
	* Widget settings
	**/
	function form( $instance ) {
		$title  = $instance['title'] ? $instance['title'] : 'Recent Posts';
		$number = $instance['number'] ? $instance['number'] : 10;
		$category = $instance['category'] ? $instance['category'] : 1;

		$categories = get_categories('hide_empty=0&orderby=name');
		$all_cats = array();
		foreach ($categories as $category_item ) {
			$all_cats[$category_item->cat_ID] = $category_item->cat_name;
		}
		//array_unshift($all_cats, "Select a category");

		// The widget form
		?>
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>"><?php echo __( 'Title:' ); ?></label>
			<input id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" class="widefat" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('number'); ?>"><?php echo __( 'Number of products to show:' ); ?></label>
			<input id="<?php echo $this->get_field_id('number'); ?>" name="<?php echo $this->get_field_name('number'); ?>" type="text" value="<?php echo $number; ?>" size="3" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('category'); ?>"><?php echo __( 'Category:' ); ?></label>
			<select name="<?php echo $this->get_field_name('category'); ?>" id="<?php echo $this->get_field_id('category'); ?>">
				<?php foreach( $all_cats as $k => $cat ) : ?>
					<option value="<?php echo $k; ?>" <?php selected($k, $category); ?>><?php echo $cat; ?></option>
				<?php endforeach; ?>
			</select>
		</p>
	<?php
	}
}
?>
