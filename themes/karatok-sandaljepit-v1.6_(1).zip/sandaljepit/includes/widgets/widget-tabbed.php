<?php
## widget_tabs
add_action( 'widgets_init', 'widget_tabs_box' );
function widget_tabs_box(){
	register_widget( 'widget_tabs' );
}
class widget_tabs extends WP_Widget {
	function widget_tabs() {
		$widget_ops = array( 'classname' => 'widget-tabs', 'description' => 'Tampilkan produk terbaru & terpopular'  );
		$this->WP_Widget( 'widget-tabs', 'Karatok Produk Tab', $widget_ops );
	}
	function widget( $args, $instance ) {
		extract( $args );
		echo $before_widget;
		?>
		<ul class="owltabs">
			<li class="selected"><a href="javascript:void(0);" class="widgettabs" data-id="0">Terbaru</a></li><!--
			--><li><a href="javascript:void(0);" class="widgettabs" data-id="1">Popular</a></li><!--
			--><li><a href="javascript:void(0);" class="widgettabs" data-id="2">Bestseller</a></li>
		</ul>
		<div id="owlwidgettabs">
			<div class="item">
				<?php
					$args = array( 'posts_per_page' => $instance['jumlahproduk'] );
					$query = new WP_Query( $args );
					if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post(); ?>
					   <article <?php post_class( 'produk-widget clearfix' ); ?>>
							<?php extract(karatok_post_meta()); ?>
							<header class="article-header">
								<div class="box-entry">
									<a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>">
										<div class="entry-thumb-widget">
											<?php the_post_thumbnail('thumbnail'); ?>
										</div>
										<h3 class="entry-title-widget"><?php the_title(); ?></h3>
									</a>
									<span class="harga-produk-widget"><?php karatok_price( $hargadiskon ); ?></span>
									<?php if( $diskon ) : ?><span class="diskon-per-widget">-<?php echo $diskon."%"; ?></span><?php endif; ?>
								</div>
							</header>
						</article>
				<?php endwhile; endif; wp_reset_query();?>
			</div>
			<div class="item">
				<?php
					global $karatok;
					$args = array(  'posts_per_page'  => $instance['jumlahproduk'],
									'meta_key'     => 'karatok_label',
									'meta_value'   => 'Popular',
									'post_type'    => 'post',
									'post_status'  => 'publish',
								);
					$query = new WP_Query( $args );
					if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post(); ?>
					   <article <?php post_class( 'produk-widget clearfix' ); ?>>
							<?php extract(karatok_post_meta()); ?>
							<header class="article-header">
								<div class="box-entry">
									<a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>">
										<div class="entry-thumb-widget">
											<?php the_post_thumbnail('thumbnail'); ?>
										</div>
										<h3 class="entry-title-widget"><?php the_title(); ?></h3>
									</a>
									<span class="harga-produk-widget"><?php karatok_price( $hargadiskon ); ?></span>
									<?php if( $diskon ) : ?><span class="diskon-per-widget">-<?php echo $diskon."%"; ?></span><?php endif; ?>
								</div>
							</header>
						</article>
					<?php endwhile; endif; wp_reset_query();?>
			</div>
			<div class="item">
				<?php
					global $karatok;
					$args = array(  'posts_per_page'  => $instance['jumlahproduk'],
									'meta_key'     => 'karatok_label',
									'meta_value'   => 'Bestseller',
									'post_type'    => 'post',
									'post_status'  => 'publish',
								);
					$query = new WP_Query( $args );
					if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post(); ?>
					   <article <?php post_class( 'produk-widget clearfix' ); ?>>
							<?php extract(karatok_post_meta()); ?>
							<header class="article-header">
								<div class="box-entry">
									<a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>">
										<div class="entry-thumb-widget">
											<?php the_post_thumbnail('thumbnail'); ?>
										</div>
										<h3 class="entry-title-widget"><?php the_title(); ?></h3>
									</a>
									<span class="harga-produk-widget"><?php karatok_price( $hargadiskon ); ?></span>
									<?php if( $diskon ) : ?><span class="diskon-per-widget">-<?php echo $diskon."%"; ?></span><?php endif; ?>
								</div>
							</header>
						</article>
					<?php endwhile; endif; wp_reset_query();?>
			</div>
		</div><!-- .widget /-->

		<?php echo $after_widget;
	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['jumlahproduk'] = strip_tags( $new_instance['jumlahproduk'] );
		return $instance;
	}

	function form( $instance ) {
		$defaults = array( 'jumlahproduk' => 5 );
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>
		<p>
			<label for="<?php echo $this->get_field_id( 'jumlahproduk' ); ?>">Number of products to show: </label>
			<input id="<?php echo $this->get_field_id( 'jumlahproduk' ); ?>" name="<?php echo $this->get_field_name( 'jumlahproduk' ); ?>" value="<?php echo $instance['jumlahproduk']; ?>" size="3" type="text" />
		</p>
	<?php
	}
}
?>
