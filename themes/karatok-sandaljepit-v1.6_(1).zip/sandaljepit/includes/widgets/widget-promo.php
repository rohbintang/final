<?php
add_action( 'widgets_init', 'karatok_widget_promo_init' );
function karatok_widget_promo_init() {
	register_widget( 'karatok_widget_promo' );
}
class karatok_widget_promo extends WP_Widget {

	function karatok_widget_promo() {
		$widget_ops = array( 'classname' => 'promo-widget cf', 'description' => 'Tampilkan promo produk sebagai banner'  );
		$this->WP_Widget( 'promo-widget', 'Karatok Promo', $widget_ops );
	}


    function widget($args, $instance) {
        extract($args);
        $offertitle = $instance['offertitle'];
        $buttontext = $instance['buttontext'];
        $offerlink = $instance['offerlink'];

        echo $before_widget;
        ?>
		<div class="h3 bungkus-promo"><?php echo $offertitle ?>
			<a href="<?php echo $offerlink ?>" class="promo-button"><?php echo $buttontext ?></a>
		</div>
        <?php
        echo $after_widget;
    }

    /* ----------------------------------------------------------------------------------- */
    /* 	Update Widget
      /*----------------------------------------------------------------------------------- */

    function update($new_instance, $old_instance) {
        $instance = $old_instance;

        // Strip tags to remove HTML (important for text inputs)
        $instance['offertitle'] = strip_tags($new_instance['offertitle']);
        $instance['buttontext'] = strip_tags($new_instance['buttontext']);
        // No need to strip tags
        $instance['offerlink'] = $new_instance['offerlink'];
        return $instance;
    }

    function form($instance) {

        // Set up some default widget settings
        $defaults = array(
            'offertitle' => 'Dapatkan Diskon Up to 50%!',
            'buttontext' => 'Lihat Sekarang',
            'offerlink' => 'http://demo.karatok.com/sandaljepit',
        );

        $instance = wp_parse_args((array) $instance, $defaults);
        ?>

        <!-- Widget Title: Text Input -->
        <p>
            <label for="<?php echo $this->get_field_id('offertitle'); ?>"><?php _e('Promo Text:', 'karatok') ?></label>
            <input class="widefat" type="text" id="<?php echo $this->get_field_id('offertitle'); ?>" name="<?php echo $this->get_field_name('offertitle'); ?>" value="<?php echo $instance['offertitle']; ?>" />
        </p>

        <!-- Button Text: Text Input -->
        <p>
            <label for="<?php echo $this->get_field_id('buttontext'); ?>"><?php _e('Promo Button:', 'karatok') ?></label>
            <input class="widefat" type="text" id="<?php echo $this->get_field_id('buttontext'); ?>" name="<?php echo $this->get_field_name('buttontext'); ?>" value="<?php echo $instance['buttontext']; ?>" />
        </p>

        <!-- Link: Link Input -->
        <p>
            <label for="<?php echo $this->get_field_id('offerlink'); ?>"><?php _e('Promo Link:', 'karatok') ?></label>
            <input class="widefat" type="text" id="<?php echo $this->get_field_id('offerlink'); ?>" name="<?php echo $this->get_field_name('offerlink'); ?>" value="<?php echo $instance['offerlink']; ?>" />
        </p>

        <?php
    }
}
?>