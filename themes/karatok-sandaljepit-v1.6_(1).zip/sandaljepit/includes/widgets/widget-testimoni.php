<?php
add_action( 'widgets_init', 'testimoni_widget_init' );
function testimoni_widget_init() {
	register_widget( 'testimoni_widget' );
}
class testimoni_widget extends WP_Widget {
	function testimoni_widget() {
		$widget_ops = array( 'classname' => 'testimoni-widget', 'description' => 'Tampilkan testimoni'  );
		$this->WP_Widget( 'testimoni-widget', 'Karatok Testimoni', $widget_ops );
	}
	function widget( $args, $instance ) {
		global $karatok;
		extract( $args );

		$title = apply_filters('widget_title', $instance['title'] );
		$number = $instance['number'];
		$words = $instance['words'];

		echo $before_widget;
		if ( $title )
			echo $before_title . $title . $after_title;

		$args = array(
			'status' => 'approve',
			'number' => $number,
			'post_id' => $karatok['testipage'], // use post_id, not post_ID
		);
		$testimoni = get_comments($args);
		?>
		<div class="testimoni-box">
			<div id="owl-testimoni" class="owl-carousel owl-theme">
			<?php foreach($testimoni as $comment) : ?>
				<?php $title = get_comment_meta( $comment->comment_ID, 'title', true ); ?>
				<?php $rating = get_comment_meta( $comment->comment_ID, 'rating', true ); ?>
				<?php $city = get_comment_meta( $comment->comment_ID, 'city', true ); ?>
				<div class="item">
					<p><strong><?php echo $title; ?></strong><br>
					<?php for( $i=1; $i<=$rating; $i++ ) echo '<i class="fa fa-star"></i>'; for( $i=$rating; $i<5; $i++ ) echo '<i class="fa fa-star-o"></i>'; ?><br>

					<?php
					echo '<span class="tukang-testi">' .$comment->comment_author .' - '.$city. '</span><br />';
					echo '<span class="isi-testi-widget">';
					echo wp_trim_words( $comment->comment_content, $words, '' ) . ' ...</span><br />'; ?>
					</p>
				</div>
			<?php endforeach; ?>
			</div>
		</div>
	<?php
		echo $after_widget;
	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['number'] = strip_tags( $new_instance['number'] );
		$instance['words'] = strip_tags( $new_instance['words'] );
		return $instance;
	}

	function form( $instance ) {
		$defaults = array( 'title' =>__( 'Testimoni' , 'karatok'), 'number' => 5, 'words' => 40 );
		$instance = wp_parse_args( (array) $instance, $defaults ); ?>

		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>">Title: </label>
			<input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" class="widefat" type="text" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'number' ); ?>">Number of testimoni to show: </label>
			<input id="<?php echo $this->get_field_id( 'number' ); ?>" name="<?php echo $this->get_field_name( 'number' ); ?>" value="<?php echo $instance['number']; ?>" type="text" size="3" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id( 'words' ); ?>">Number of words to show: </label>
			<input id="<?php echo $this->get_field_id( 'words' ); ?>" name="<?php echo $this->get_field_name( 'words' ); ?>" value="<?php echo $instance['words']; ?>" type="text" size="3" />
		</p>


	<?php
	}
}
?>
