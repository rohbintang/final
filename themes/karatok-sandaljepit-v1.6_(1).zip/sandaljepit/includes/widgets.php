<?php
include (TEMPLATEPATH . '/includes/widgets/widget-category.php');
include (TEMPLATEPATH . '/includes/widgets/widget-kcategory.php');
include (TEMPLATEPATH . '/includes/widgets/widget-contact.php');
include (TEMPLATEPATH . '/includes/widgets/widget-facebook.php');
include (TEMPLATEPATH . '/includes/widgets/widget-info-toko.php');
include (TEMPLATEPATH . '/includes/widgets/widget-tabbed.php');
include (TEMPLATEPATH . '/includes/widgets/widget-rekening.php');
include (TEMPLATEPATH . '/includes/widgets/widget-testimoni.php');
include (TEMPLATEPATH . '/includes/widgets/widget-blog-category.php');
include (TEMPLATEPATH . '/includes/widgets/widget-blog-by-category.php');
include (TEMPLATEPATH . '/includes/widgets/widget-recent-blog-posts.php');
include (TEMPLATEPATH . '/includes/widgets/widget-ekspedisi.php');
include (TEMPLATEPATH . '/includes/widgets/widget-promo.php');
?>
