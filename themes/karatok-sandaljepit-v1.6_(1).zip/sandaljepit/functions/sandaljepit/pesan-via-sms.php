<?php
function karatok_pesanviasms() { global $karatok; ?>
	<div id="pesanviasms" class="list-isi-pesan">
		<p class="h2"><i class="fa fa-mobile"></i>Format Pemesanan Via SMS</p>
		<p class="h3"><?php echo str_replace("[nohp]", $karatok['nohp'], $karatok['formatsms']); ?></p>
		<p class="h3 instruksisms">Selanjutnya kami akan membalas SMS anda dengan rincian total belanja anda yang harus ditransfer ke rekening kami</p>

		<div class="fancy-bank-list clearfix">
			<a href="#rekeningbank" class="h4 rekeningbank">Lihat List Rekening Kami<i class="fa fa-angle-right fa-lg"></i></a>
			<?php karatok_daftar_rekening() ?>
		</div>

		<div class="fancy-kontak-list clearfix">
			<h4>Butuh bantun mengenai produk kami? Silahkan hubungi kami melalui kontak di bawah ini</h4>
			<ul>
				<?php foreach( $karatok['kontak'] as $kontak ) : ?>
				<?php $kontak = explode( '|', $kontak ); ?>
				<li class="kontak-list"><span><?php echo $kontak[0]; ?></span><?php echo $kontak[1]; ?></li>
				<?php endforeach; ?>
			</ul>
		</div>
	</div>
<?php } ?>