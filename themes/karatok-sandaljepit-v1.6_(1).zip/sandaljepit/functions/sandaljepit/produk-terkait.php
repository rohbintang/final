<?php
function karatok_produk_terkait() {
	global $post, $karatok;
	$tags = wp_get_post_tags( $post->ID );
	if($tags) :
		foreach( $tags as $tag ) {
			$tag_arr .= $tag->slug . ',';
		}
		$args = array(
			'tag' => $tag_arr,
			'posts_per_page' => $karatok['jumlahproduktabs'],
			'post__not_in' => array($post->ID)
		);
		$query = new WP_Query( $args );
		if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post(); ?>
			<?php get_template_part( 'entry', 'content' ); ?>
		<?php endwhile; ?>
		<?php else : ?>
			<div class="alert alert-info"><p>Tidak ada produk berkaitan.</p></div>
		<?php endif; wp_reset_query();
	else : ?>
		<div class="alert alert-info"><p>Tidak ada produk berkaitan.</p></div>
	<?php endif;
}
?>
