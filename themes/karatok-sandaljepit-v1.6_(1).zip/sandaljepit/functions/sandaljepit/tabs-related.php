<?php
function karatok_tabs_related() {
	global $karatok;
	if( $karatok['singletabson'] ) {
		$tabs = array(
					'produkterkait' => 'Produk Terkait',
					'produkpopular' => 'Popular',
					'produkbestseller' => 'Bestseller',
					'produkterbaru' => 'Terbaru'
				); ?>
		<section id="relatedtabs" class="twelvecol first clearfix">
			<ul class="owltabs"><!--
			<?php $i = 0; foreach( $tabs as $tab => $title ) : ?>
				<?php if( $karatok[$tab] ) : ?>
				--><li <?php echo ( $i == 0 ) ? 'class="selected"' : ''; ?>><a href="javascript:void(0);" class="relatedtabs" data-id="<?php echo $i; ?>"><?php echo $title; ?></a></li><!--
				<?php endif; ?>
			<?php $i++; endforeach; ?>
			--></ul>
			<div id="owlrelatedtabs">
				<?php if( $karatok['produkterkait'] ) : ?>
				<div class="item">
					<?php karatok_produk_terkait() ?>
				</div>
				<?php endif; ?>
				<?php if( $karatok['produkpopular'] ) : ?>
				<div class="item">
					<?php karatok_produk_popular() ?>
				</div>
				<?php endif; ?>
				<?php if( $karatok['produkbestseller'] ) : ?>
				<div class="item">
					<?php karatok_produk_bestseller() ?>
				</div>
				<?php endif; ?>
				<?php if( $karatok['produkterbaru'] ) : ?>
				<div class="item">
					<?php karatok_produk_terbaru() ?>
				</div>
				<?php endif; ?>
			</div>
		</section>
	<?php }
} ?>
