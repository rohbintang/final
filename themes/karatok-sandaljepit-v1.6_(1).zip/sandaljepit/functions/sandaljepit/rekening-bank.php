<?php
function karatok_daftar_rekening() {
	global $karatok; ?>
	<div id="rekeningbank" class="list-rekening">
		<h2>Pembayaran via Bank</h2>
		<p class="h3">Harap segera konfirmasi jika pembayaran sudah ditransfer ke rekening di bawah ini.</p>
		<ul>
			<?php foreach( $karatok['rekbank'] as $bank ) : ?>
			<?php $bank = explode( '|', $bank ); ?>
			<li class="twelvecol first clearfix">
				<span class="nama-bank twocol first"><?php echo $bank[0]; ?></span>
				<span class="bungkus-rekening eightcol">
					<span class="nama-rekening"><?php echo $bank[1]; ?></span>
					<span class="nomor-rekening"><?php echo $bank[2]; ?></span>
				</span>
			</li>
			<?php endforeach; ?>
		</ul>
	</div>
<?php } ?>
