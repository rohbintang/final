<?php
function karatok_artikel_terbaru() {
	global $karatok, $paged;
	if( $karatok['artikelon'] && is_home() && $paged < 2 ) : ?>
	<div class="artikel-terbaru">
		<?php if( $karatok['artikeltitle'] ) : ?><h2 class="h3"><?php echo $karatok['artikeltitle']; ?></h2><?php endif; ?>
		<?php $mlq = new WP_Query(
					array(
						'post_type' => 'custom_type',
						'posts_per_page' => $karatok['jumlahartikel']
					)
				);
		if( $mlq->have_posts() ) : while($mlq->have_posts()) : $mlq->the_post(); ?>
		<article id="post-<?php the_ID(); ?>" <?php post_class( 'blog-home clearfix' ); ?> role="article">
			<header class="article-header">
				<div class="blog-home-entry">
					<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
						<div class="thumb-blog-home">
							<?php the_post_thumbnail('medium'); ?>
						</div>
						<h3 class="judul-blog-home"><?php the_title(); ?></h3>
					</a>
					<section><?php the_excerpt(); ?></section>
				</div>
			</header>
		</article>
		<?php endwhile; ?>
		<?php else : ?>
			<div class="alert alert-help"><p>Tidak ada artikel untuk ditampilkan.</p></div>
		<?php endif; wp_reset_query(); ?>
	</div>
	<?php endif; ?>
<?php } ?>