<article <?php post_class( 'bungkus-produk threecol clearfix' ); ?>>
	<header class="article-header">
		<?php extract(karatok_post_meta()); ?>
		<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
			<div class="entry-thumb">
				<div class="fitur-produk">
					<?php if( $diskon ) : ?>
					<div class="diskon-per">
						<span>-<?php echo $diskon."%"; ?></span>
					</div>
					<?php endif; ?>
					<?php if( $label ) : ?>
					<div class="popular-produk <?php echo strtolower( $label ); ?>">
						<span><?php echo $label; ?></span>
					</div>
					<?php endif; ?>
				</div>
				<?php the_post_thumbnail('medium'); ?>
				<?php if( $stok == 'habis' ) : ?>
					<div class="product-stockbg">
						<div class="product-stock"><?php global $karatok; echo $karatok['stokhabis']; ?></div>
					</div>
				<?php endif; ?>

			</div>
			<h2 class="h4 entry-title judul-produk twelvecol first clearfix"><?php the_title(); ?></h2>
		</a>

		<div class="bungkus-harga twelvecol first">
			<p class="harga-produk sevencol first"><?php karatok_price( $hargadiskon ); ?></p>
			<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>" class="footer-addcart fivecol last">detail</a>
		</div>
	</header>

	<footer class="article-footer">
		<p class="tags" style="display:none;"><?php the_tags( '<span class="tags-title">' . __( 'Tags:', 'karatok' ) . '</span> ', ', ', '' ); ?></p>
	</footer>
</article>
