<?php
/*
This is the custom post type taxonomy template.
If you edit the custom taxonomy name, you've got
to change the name of this template to
reflect that name change.

i.e. if your custom taxonomy is called
register_taxonomy( 'shoes',
then your single template should be
taxonomy-shoes.php

*/
?>

<?php get_header(); ?>

			<div id="content">

				<div id="inner-content" class="wrap clearfix">

						<div id="main" class="ninecol halaman-blog first clearfix" role="main">

							<div id="breadcrumbs" class="breadcrumbs clearfix"><?php karatok_breadcrumbs() ?></div>

							<h1 class="archive-title h2"><span><?php _e( 'Posts Categorized:', 'karatok' ); ?></span> <?php single_cat_title(); ?></h1>

							<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

							<article id="post-<?php the_ID(); ?>" <?php post_class( 'clearfix' ); ?> role="article">

								<section class="entry-blog-archive clearfix">
									<div class="entry-thum-blog fourcol first clearfix">
										<?php the_post_thumbnail('medium'); ?>
									</div>
									<div class="entry-blog-summary eightcol last clearfix">
										<h2 class="h2"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
										<p class="byline vcard"><?php
											printf( __( 'Posted <time class="updated" datetime="%1$s" pubdate>%2$s</time> by <span class="author">%3$s</span>.', 'karatok' ), get_the_time( 'Y-m-j' ), get_the_time( __( 'F jS, Y', 'karatok' ) ), karatok_get_the_author_posts_link());
										?></p>

										<?php the_excerpt(); ?>
									</div>



								</section>

							</article>

							<?php endwhile; ?>

									<?php if ( function_exists( 'karatok_page_navi' ) ) { ?>
											<?php karatok_page_navi(); ?>
									<?php } else { ?>
											<nav class="wp-prev-next">
													<ul class="clearfix">
														<li class="prev-link"><?php next_posts_link( __( '&laquo; Older Entries', 'karatok' )) ?></li>
														<li class="next-link"><?php previous_posts_link( __( 'Newer Entries &raquo;', 'karatok' )) ?></li>
													</ul>
											</nav>
									<?php } ?>

							<?php else : ?>

									<article id="post-not-found" class="hentry clearfix">
										<header class="article-header">
											<h1><?php _e( 'Oops, Post Not Found!', 'karatok' ); ?></h1>
										</header>
										<section class="entry-content">
											<p><?php _e( 'Uh Oh. Something is missing. Try double checking things.', 'karatok' ); ?></p>
										</section>
										<footer class="article-footer">
												<p><?php _e( 'This is the error message in the taxonomy-custom_cat.php template.', 'karatok' ); ?></p>
										</footer>
									</article>

							<?php endif; ?>

						</div>

						<?php get_sidebar('blog'); ?>

				</div>

			</div>

<?php get_footer(); ?>
