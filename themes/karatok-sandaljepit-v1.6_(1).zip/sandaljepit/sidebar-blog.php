				<div id="sidebar-blog" class="sidebar-footer threecol first clearfix" role="complementary">

					<?php if ( is_active_sidebar( 'sidebar-blog' ) ) : ?>

						<?php dynamic_sidebar( 'sidebar-blog' ); ?>

					<?php else : ?>

						<?php // This content shows up if there are no widgets defined in the backend. ?>

						<div class="alert alert-help">
							<p><?php _e( 'Please activate some widgets in Sidebar Blog.', 'karatok' );  ?></p>
						</div>

					<?php endif; ?>

				</div>
