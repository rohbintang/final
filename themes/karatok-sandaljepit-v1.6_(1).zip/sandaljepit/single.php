<?php get_header(); ?>

			<div id="content">

				<div id="inner-content" class="wrap clearfix">

					<div id="main" class="ninecol last clearfix" role="main">

						<div id="breadcrumbs" class="breadcrumbs clearfix"><?php karatok_breadcrumbs() ?></div>

						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

							<article id="post-<?php the_ID(); ?>" <?php post_class('clearfix'); ?> itemscope itemtype="http://data-vocabulary.org/Product">

								<section class="entrycontent twelvecol first clearfix">

									<section class="thumbmedium-box fourcol first clearfix">
									<?php
									$thumbnail = wp_get_attachment_image_src( get_post_thumbnail_id(), 'thumbnail' );
									$large = wp_get_attachment_image_src( get_post_thumbnail_id(), 'large' );
									$original = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full' );
									$thumbcart = $thumbnail[0];
									echo '<div class="sj-left-image-product nospace"><img itemprop="image" id="single-ezoom" src="'.$large[0].'" data-zoom-image="'.$original[0].'" alt="'.get_the_title().'"/></div>';

									$args = array(
										'post_type' => 'attachment',
										'numberposts' => -1,
										'post_status' => null,
										'post_parent' => $post->ID,
										'exclude'     => get_post_thumbnail_id()
									);

									//echo get_post_thumbnail_id();

									$attachments = get_posts( $args );
									echo '<div id="single-egallery">';
									echo '<a href="#" class="elevatezoom-gallery active" data-image="'.$large[0].'" data-zoom-image="'.$original[0].'"><img src="'.$thumbnail[0].'" alt="'.get_the_title().'" class="nospace"/></a>';

									if ( $attachments ) {
										foreach ( $attachments as $attachment ) {
											$thumbnail = wp_get_attachment_image_src( $attachment->ID, 'thumbnail' );
											$large = wp_get_attachment_image_src( $attachment->ID, 'large' );
											$original = wp_get_attachment_image_src( $attachment->ID, 'full' );
											echo '<a href="#" class="elevatezoom-gallery" data-image="'.$large[0].'" data-zoom-image="'.$original[0].'"><img src="'.$thumbnail[0].'" alt="'.$attachment->post_title.'" class="nospace"/></a>';
										}
									}
									echo '</div>';
									?>
									</section><!-- akhir .entry-thumbmedium -->

									<section class="deskripsi-produk eightcol last">
										<div class="product-shop twelvecol first">
											<h1 class="h2 judul-produk-single" itemprop="name"><?php the_title(); ?></h1>
											<?php extract(karatok_post_meta()); ?>
											<div class="entry-price-box eightcol first clearfix" itemprop="offerDetails" itemscope itemtype="http://data-vocabulary.org/Offer">
												<div class="price-single">
													Rp <span itemprop="price"><?php karatok_price($hargadiskon, 1, 0); ?></span>
													<?php foreach( explode( ",", $ukuran ) as $k => $size ) :
														$size = explode( "-", trim( $size ) );
														$hargaku = $size[1];
														$asli = '';
														if( $diskon ) {
															$hargaku = $hargaku - ( $hargaku * $diskon / 100 );
															$asli = "<span class='asli'>".karatok_price($size[1], 0)."</span>";
														}
														if( $hargaku )
															$regone .= "<span class='hargaper-ukuran'>$asli".karatok_price($hargaku, 0)."<span class='ukuran'>{$size[0]}</span></span>";
														endforeach;
													?>
													<?php if( $regone ) : ?>
													<i title="Lihat detail harga" class="fa fa-angle-down"></i>
													<div class="hargaukuran-box tugelhide">
														<?php echo $regone; ?>
													</div>
													<?php endif; ?>
													<span itemprop="currency" content="IDR"></span><?php if( $stok == 'ada' ) $instock = 'in_stock'; else $instock = 'out_of_stock'; ?>
													<span itemprop="availability" content="<?php echo $instock; ?>"></span>
												</div>
												<?php if( $diskon ) : ?><div class="single-price-discount"><?php karatok_price($harganormal); ?></div><?php endif; ?>

											</div>
											<?php if( $diskon ) : ?>
											<div class="entry-discount-box fourcol">
												<div class="discount-single"><?php echo $diskon; ?>% OFF</div>
											</div>
											<?php endif; ?>

											<div class="entry-stock-box twelvecol first clearfix">
												<?php if( $stok == 'ada' ) : ?>
													<div class="single-stock ada">Stok Tersedia<i class="fa fa-check-circle"></i></div>
												<?php else : ?>
													<div class="single-stock habis">Stok Habis<i class="fa fa-times-circle"></i></div>
												<?php endif; ?>
											</div>

											<form class="jcart entry-cart-button twelvecol first clearfix" method="post">

												<div class="sj-product-detail-box twelvecol first clearfix">
													<div class="sj-rating clearfix">
														<div class="sj-box-left-detail threecol first">Rating</div>
														<div class="sj-box-right-detail ninecol last">:
															<?php for( $i=1; $i<=floor($rating); $i++ ) : ?>
															<i class="fa fa-star"></i>
															<?php endfor; ?>
															<?php if( $rating != floor($rating) ) : ?>
															<i class="fa fa-star-half-o"></i>
															<?php endif; ?>
															<?php for( $i=ceil($rating); $i<5; $i++ ) : ?>
															<i class="fa fa-star-o"></i>
															<?php endfor; ?>
															<span itemprop="review" itemscope itemtype="http://data-vocabulary.org/Review-aggregate">
																<span itemprop="rating"><?php echo $rating ? $rating : 0; ?></span>/5<span itemprop="count" content="99"></span>
															</span>
														</div>

													</div>
													<?php if( $kode ) : ?>
													<div class="sj-product-code clearfix">
														<div class="sj-box-left-detail threecol first">Kode</div>
														<div class="sj-box-right-detail ninecol last">: <span itemprop="productID"><?php echo $kode; ?></span></div>
													</div>
													<?php endif; ?>
													<div class="sj-product-cat clearfix">
														<div class="sj-box-left-detail threecol first">Kategori</div>
														<div class="sj-box-right-detail ninecol last">: <?php the_category(', '); ?></div>
													</div>
													<?php if( $berat ) : ?>
													<div class="sj-product-weight clearfix">
														<div class="sj-box-left-detail threecol first">Berat</div>
														<div class="sj-box-right-detail ninecol last">: <?php echo $berat; ?> KG</div>
													</div>
													<?php endif; ?>
													<?php if( $ukuran ) : ?>
													<div class="sj-product-attr clearfix">
														<div class="sj-box-left-detail threecol first">Ukuran</div>
														<div class="sj-size-box ninecol last">:
															<?php foreach( explode( ",", $ukuran ) as $k => $size ) :
																$size = explode( "-", trim( $size ) ); $hargaku = $size[1];
																if( $diskon ) {
																	$hargaku = $size[1] - ( $size[1] * $diskon / 100 );
																}
																echo "<input data-hargaku=\"$hargaku\" type=\"radio\" id=\"size$k\" name=\"my-item-size\" value=\"{$size[0]}\" ".checked($k, 0, 0)."><label for=\"size$k\">{$size[0]}</label>";
															endforeach; ?>
														</div>
													</div>
													<?php endif; ?>
													<?php if( $warna ) : ?>
													<div class="sj-product-attr clearfix">
														<div class="sj-box-left-detail threecol first">Warna</div>
														<div class="sj-color-box ninecol last">:
															<?php foreach( explode( ",", $warna ) as $k => $warni ) :
																if( $warni = trim( $warni ) ) echo "<input type=\"radio\" id=\"warna$k\" name=\"my-item-color\" value=\"$warni\" ".checked($k, 0, 0)."><label for=\"warna$k\" class=\"$warni\" title=\"Warna $warni\">&nbsp;</label>";
															endforeach; ?>
														</div>
													</div>
													<?php endif; ?>
												</div>

												<input type="hidden" name="jcartToken" value="<?php echo $_SESSION['jcartToken'];?>" />
												<input type="hidden" name="my-item-id" value="<?php echo $kode ? $kode : get_the_ID(); ?>" />
												<input type="hidden" name="my-item-name" value="<?php the_title(); ?>" />
												<input type="hidden" name="my-item-price" value="<?php echo $hargadiskon; ?>" />
												<input type="hidden" name="my-item-weight" value="<?php echo $berat; ?>" />
												<input type="hidden" name="my-item-url" value="<?php the_permalink(); ?>" />
												<input type="hidden" name="my-item-thumb" value="<?php echo $thumbcart; ?> " />
												<input type="hidden" name="my-item-qty" value="1"/>
												<?php $last = 'first'; ?>
												<?php if( $karatok['buttontexton'] ) : $last = 'last'; ?>
												<input type="submit" name="my-add-button" class="addtocart button sixcol first" value="<?php echo $karatok['buttontext']; ?>" <?php disabled( $stok, 'habis' ); ?>>
												<?php endif; ?>
												<?php if( $karatok['tombolviasms'] ) : ?><a href="#pesanviasms" class="pesanviasms sixcol <?php echo $last; ?>">Pemesanan via SMS</a><?php endif; ?>
											</form>

											<div class="sj-product-detail twelvecol first clearfix">
												<div id="expanderHead">
													Detail Produk<span id="expanderSign">lihat ▼</span>
												</div>
												<div id="expanderContent" style="display:none">
													<div itemprop="description"><?php the_content(); ?></div>
												</div>
											</div>

											<div class="sj-social-share twelvecol first clearfix">
												<div class="sj-social-share-text">bagikan ke teman</div>
												<!-- AddThis Button BEGIN -->
												<div class="addthis_toolbox addthis_default_style addthis_16x16_style">
													<a class="addthis_button_facebook"></a>
													<a class="addthis_button_twitter"></a>
													<a class="addthis_button_google_plusone_share"></a>
													<a class="addthis_button_pinterest_share"></a>
													<a class="addthis_button_email"></a>
												</div>
												<script type="text/javascript">var addthis_config = {"data_track_addressbar":false};</script>
												<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-530f12991170d082"></script>
												<!-- AddThis Button END -->
											</div>

										</div>

									</section><!-- akhir .entry-description -->

								</section><!-- akhir .entry-content -->

								<?php //comments_template(); ?>

							</article><!-- akhir #post-ID -->
							<section class="pernah-box twelvecol first clearfix">
								<?php if( $karatok['pernahdilihat'] ) : ?>
								<div class="pernah-dilihat">
									<h5 class="judul-pernah-dilihat">Pernah Dilihat</h5>
									<?php
										global $sj_seen;
										$categories = get_the_category();
										$cat_id = $categories[0]->term_id;

										$args = array(
											//'cat' => $cat_id,
											'post__in' => explode( ',', $sj_seen ),
											'post__not_in' => array($post->ID),
											'posts_per_page'=> $karatok['jumlahpernahdilihat']
										);
										$my_query = new wp_query( $args );

										echo '<ul>';
										if ( $my_query->have_posts() ) : while ( $my_query->have_posts() ) : $my_query->the_post(); ?>

											<?php extract(karatok_post_meta()); ?>

											<li class="ever-thumb twocol">
												<div class="fitur-produk">
													<?php if( $diskon ) : ?>
													<div class="diskon-per">
														<span>-<?php echo $diskon."%"; ?></span>
													</div>
													<?php endif; ?>
												</div>
												<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
													<?php the_post_thumbnail('medium'); ?>
												</a>
												<?php if( $stok == 'habis' ) : ?>
													<div class="ever-stockbg">
														<div class="ever-stock"><?php global $karatok; echo $karatok['stokhabis']; ?></div>
													</div>
												<?php endif; ?>
												<p class="ever-harga"><?php karatok_price( $hargadiskon ); ?></p>

											</li>

										<?php endwhile;	endif; wp_reset_query(); ?>
										</ul>
										<div class="clear"></div>
								</div>
								<?php endif; ?>
							</section>
							<?php karatok_tabs_related(); ?>

						<?php endwhile; ?>

						<?php else : ?>

							<article id="post-not-found" class="hentry clearfix">
								<header class="article-header">
									<h1><?php _e( 'Oops, Post Not Found!', 'karatok' ); ?></h1>
								</header>
								<section class="entry-content">
									<p><?php _e( 'Uh Oh. Something is missing. Try double checking things.', 'karatok' ); ?></p>
								</section>
								<footer class="article-footer">
										<p><?php _e( 'This is the error message in the single.php template.', 'karatok' ); ?></p>
								</footer>
							</article>

						<?php endif; ?>

					</div><!-- akhir #main -->

					<?php get_sidebar(); ?>

				</div><!-- akhir #inner-content -->

			</div><!-- akhir #content -->

<?php get_footer(); ?>
